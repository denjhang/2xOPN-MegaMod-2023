# YM2203_JukeBox

## Arduino Sketch

[Sketch](YM2203_JukeBox.ino)

## Schematic

![schematic](YM2023_JukeBox_Sch.png)
[PDF](YM2023_JukeBox_Sch.pdf)
