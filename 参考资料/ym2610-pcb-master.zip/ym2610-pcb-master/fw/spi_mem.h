// spi_mem.h
//
// Copyright (C) 2021 Dan Rodrigues <danrr.gh.oss@gmail.com>
//
// SPDX-License-Identifier: MIT

#ifndef spi_mem_h
#define spi_mem_h

void spi_mem_init(void);

#endif

