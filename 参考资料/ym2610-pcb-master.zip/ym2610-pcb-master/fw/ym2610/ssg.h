// ssg.h
//
// Copyright (C) 2021 Dan Rodrigues <danrr.gh.oss@gmail.com>
//
// SPDX-License-Identifier: MIT

#ifndef ssg_h
#define ssg_h

void ssg_mute_all(void);

#endif
