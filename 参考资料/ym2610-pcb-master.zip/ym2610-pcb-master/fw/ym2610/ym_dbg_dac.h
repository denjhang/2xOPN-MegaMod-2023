// ym_dbg_dac.h
//
// Copyright (C) 2021 Dan Rodrigues <danrr.gh.oss@gmail.com>
//
// SPDX-License-Identifier: MI

#include <stdint.h>

#ifndef ym_dbg_dac_h
#define ym_dbg_dac_h

void ym_dbg_dac_previous_inputs(uint16_t *left, uint16_t *right);

#endif
