ctx.addClock("clk_24m", 24)
ctx.addClock("clk_48m", 48)
